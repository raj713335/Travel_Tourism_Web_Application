package com.travels_webapp.Model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.travels_webapp.Beans.RegisterBean;

public class UserDB {
	
	String s1=null;
	
	
	/*public String insertUser(RegisterBean rb) {*/
	public String WriteData(RegisterBean rb) {
		MyDb db=new MyDb();
		Connection con=db.getCon();
		try {
			Statement stmt=con.createStatement();
			stmt.executeUpdate("insert into travels_webapp.register(name,location,email,password,confirm_password) values ('"+rb.getName()+"','"+rb.getLocation()+"','"+rb.getEmail()+"','"+rb.getPassword()+"','"+rb.getConfirm_password()+"')");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "Data Inserted";
		
		
	}
	
	/*slaying the codes one by one*/
	
	public String readData(RegisterBean rb)
	{
		MyDb db=new MyDb();
		ResultSet rs;
		String s1="null";
		
		Connection con=db.getCon();
		try {
			Statement stmt=con.createStatement();
			rs=stmt.executeQuery("select email,password from travels_webapp.register where email='"+rb.getEmail()+"' and password='"+rb.getPassword()+"'");
			if(rs.next()) {
				s1="sucess";
			}
			
			//System.out.println(rb.getPassword());
			
	         
	           
	          
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//System.out.print(s2);
		return s1;
		
		}

}
