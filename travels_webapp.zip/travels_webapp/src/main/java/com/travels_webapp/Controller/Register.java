package com.travels_webapp.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.travels_webapp.Beans.RegisterBean;
import com.travels_webapp.Model.UserDB;

/**
 * Servlet implementation class Register
 */
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		PrintWriter out=response.getWriter();
		
		String name=request.getParameter("name");
		String location=request.getParameter("location");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String confirm_password=request.getParameter("confirm_password");
		
		//out.println(name+location+email+password+confirm_password);
		
		RegisterBean rb=new RegisterBean();
		
		rb.setName(name);
		rb.setLocation(location);
		rb.setEmail(email);
		rb.setPassword(password);
		rb.setConfirm_password(confirm_password);
		
		UserDB ud=new UserDB();
		
		String s1=ud.WriteData(rb);
		
		System.out.println(s1);
		/*PrintWriter out=response.getWriter();
		
		String name=request.getParameter("name");
		String location=request.getParameter("location");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String confirm_password=request.getParameter("confirm_password");
		
		//out.println(name+location+email+password+confirm_password);
		
		RegisterBean rb=new RegisterBean();
		
		rb.setName(name);
		rb.setLocation(location);
		rb.setEmail(email);
		rb.setPassword(confirm_password);
		rb.setConfirm_password(confirm_password);
		
		UserDB ud=new UserDB();
		
		String s1=ud.WriteData(rb);
		
		System.out.println(s1);*/
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
		
		
	}

}
