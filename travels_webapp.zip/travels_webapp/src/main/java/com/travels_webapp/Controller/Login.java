package com.travels_webapp.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.travels_webapp.Beans.RegisterBean;
import com.travels_webapp.Model.UserDB;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		
		RegisterBean rb=new RegisterBean();
		rb.setEmail(email);
		rb.setPassword(password);
		
		
		
		
		UserDB ud=new UserDB();
		String s1=ud.readData(rb);
		
		if(s1.equalsIgnoreCase("sucess")) {
			
			HttpSession session=request.getSession();
			session.setAttribute("email", email);
			response.sendRedirect("http://localhost:8080/travels_webapp/logout.jsp");
		}
		else {
			response.sendRedirect("http://localhost:8080/travels_webapp/fail.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
		
		
		
	}

}
